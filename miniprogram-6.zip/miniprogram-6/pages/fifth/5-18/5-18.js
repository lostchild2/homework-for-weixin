// pages/index/5-18/5-18.js

Page({
  data:{
    title:''
  },
  inputTitle:function(e){
    this.data.title=e.detail.value
  },
  setTitle:function(){
    wx.setNavigationBarTitle({
      title:this.data.title
    })
  },
  setColor:function(){
    wx.setNavigationBarColor({
      backgroundColor: '#ff0000',
      frontColor: '#ffffff',
      animation:{
        duration:4000,
        timingFunc:'easeInOut'
      }
    })
  },
  setAnime:function(){
    wx.showNavigationBarLoading();
  },
  stopAnime:function(){
    wx.hideNavigationBarLoading();
  }
})