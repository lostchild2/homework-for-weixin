// pages/fifth/5-19/index.js
Page({
    showTarBar:function(){
        wx.showTabBar({
          animation:true,
        })
    },
    hideTabBar:function(){
        wx.hideTabBar({
            animation:true,
        })
    },
    setTabBarBadge:function(){
        wx.removeTabBarBadge({
          index: 3,
        })
    },
    removeTabBarBadge:function(){
        wx.removeTabBarBadge({
          index: 3,
        })
    },
    showTarBarRedDot:function(){
        wx.showTabBarRedDot({
          index: 1,
        })
    },
    hideTabBarRedDot:function(){
        wx.hideTabBarRedDot({
          index: 1,
        })
    },
    setTabBarStyle:function(){
        wx.setTabBarStyle({
            color:'#ff0000',
            selectedColor:'#0000ff',
            backgroundColor:'#ffff00',
            borderStyle:'',
        })
    },
    setTabBarItem:function(){
        wx.setTabBarStyle({
            color:'#00000',
            selectedColor:'#00ff00',
            backgroundColor:'#fff',
            borderStyle:'',
        })
        wx.setTabBarItem({
          index: 4,
          text:'关于我们',
          iconPath:'/images/guanyu_dianhua.png',
          selectedColorPath:'/images/guanyu_jieshao.png',
        })
    },
    reset:function(){
        wx.setTabBarStyle({
            color:'#00000',
            selectedColor:'#00ff00',
            backgroundColor:'#fff',
            borderStyle:'',
        })
        wx.setTabBarItem({
          index: 4,
          text:'关于我们',
          iconPath:'/images/guanyu_jieshao.png',
          selectedColorIconPath:'/images/guanyu_youshi.png'
        })
    }
})