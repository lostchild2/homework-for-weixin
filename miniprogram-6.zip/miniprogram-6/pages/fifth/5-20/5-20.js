// pages/fifth/5-20/5-20.js
var myItemList=['第一项','第二项','第三项','第四项']
Page({
    showActionSheet:function(){
        var that=this;
        wx.showActionSheet({
          itemList: myItemList,
          itemColor:'#0000FF',
          success:function(e){
            that.setData({
                tapIndex:e.tapIndex,
            tapItem:myItemList[e.tapIndex]
            })
          }
        })
    },
    fail:function(e){
        that.setData({
            tapIndex:-1,
            tapItem:'取消'
        })
    },
    complete:function(e){},
})