// pages/index/2-8/2-8.wxml.js
Page({
    cal:function(a){
        var C,b;
        C=a.detail.value;
        this.setData({
            b:C*9/5+32
        })
    }
})