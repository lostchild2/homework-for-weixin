// pages/index/2-3/2-3.wxml.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  tapCat:function(){
    let audio=wx.createInnerAudioContext();
    audio.src="../../../image/meow.mp3";
    audio.play();
  }
  
})