// pages/index/2-11/2-11.wxml.js
var start,final,sum;
Page({
    
    startNum:function(x){
        start=parseInt(x.detail.value);
    },
    finalNum:function(x){
        final=parseInt(x.detail.value);
    },
    cal:function(){
        sum=0;
        for(var i=start;i<=final;i++){
            sum+=i;
        }
        this.setData({
            sum:sum
        })
    }
})