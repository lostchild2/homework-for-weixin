// pages/index/2-13/2-13.js
var num=60;
var timerID;
Page({
    data:{
        hidden:true,
        btnDisabled:false,
        num:num
    },
    onLoad:function(options){
        var that=this;
        setTimeout(()=>{
            that.show()
        },2000)
    },
    show:function(){
        var that=this;
        that.setData({
            hidden:false
        })
    },
    start:function(){
        var that=this;
        that.setData({
            btnDisabled:true
        })
        timerID=setInterval(()=>{
            that.timer()
        },1000)
    },
    stop:function(){
        clearInterval(timerID)
        this.setData({
            btnDisabled:false
        })
    },
    timer:function(){
        var that=this;
        if(num>0){
            that.setData({
                num:num--
            })
        }
        else{
            that.setData({
                num:0
            })
        }
        console.log(num)
    }
})