// pages/index/2-12/2-12.js
var rand=[];
var sum=0;
function createRand(){
    rand=[];
    sum=0;
    for(var i=0;i<6;i++){
        
        var r=(Math.random()*100).toFixed(2)*1;
        rand.push(r);
        sum+=r;
    }

}
Page({
    onLoad:function(){
        createRand();
        this.setData({
            rand:rand,
            sum:sum
        })
    },
    newRand:function(){
        createRand();
        this.setData({
            rand:rand,
            sum:sum
        })
    }
})