// pages/index/2-10/2-10.wxml.js
Page({
    data:{
        flag:true,
        name:'',
        score1:'',
        score2:'',
        avr:''
    },
    put1:function(str) {
        this.setData({
            name:str.detail.value
        });
    },
    put2:function(num){
        this.setData({
            score1:parseInt(num.detail.value)
        });
    },
    put3:function(num2){
        this.setData({
            score2:parseInt(num2.detail.value)
        });
    },
    mysubmit:function(num){
        if(this.data.name==''||this.data.score1==''||this.data.score2==''){
            return ;
        }
        else{
            var avrage=(this.data.score1+this.data.score2)/2;
            this.setData({
                avr:avrage,
                flag:false
            });
        }
    }

})