
// pages/fiffth/5-9/5-9.js
Page({
    chooseimage:function(){
        var that=this;
        wx.chooseImage({
            count: 1,
            sizeType: ['original','compressed'],
            sourceType: ['album','camera'],
            success: (result) => {
                wx.showToast({
                    title:res.tempFilePaths,
                    icon:'success',
                    duration:2000
                  })
                that.setData({
                    imgPath:res.tempFilePaths
                })
            }
          })
    },
    chooseVideo:function(){
        var that=this;
        wx.chooseVideo({
            camera: ['front','camera'],
          compressed: true,
          maxDuration: 60,
          sourceType: ['album','camera'],
          success: (result) => {
              wx.showToast({
                title:res.tempFilePaths,
                icon:'success',
                duration:2000
              })
              that.setData({
                videoPath:res.tempFilePaths
            })
          },
          fail: (res) => {},
          complete: (res) => {},
        })
    }
})