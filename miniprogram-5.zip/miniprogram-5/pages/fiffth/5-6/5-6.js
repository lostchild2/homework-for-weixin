var ctx=wx.createCanvasContext('myCanvas');
Page({
    drawDot:function(x,y){
        ctx.arc(x,y,3,0,2*Math.PI)
        ctx.setFillStyle('green')
        ctx.fill()
        ctx.draw(true)
    },
    drawSinx:function(){
        for(var i=0;i<2*Math.PI;i+=Math.PI/180){
            var y=Math.sin(i);
            this.drawDot(10+50*i,60+50*y);
        }
    },
    onLoad:function(options){
        this.drawSinx()
    }
})