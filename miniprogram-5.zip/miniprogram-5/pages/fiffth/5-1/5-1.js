// pages/fiffth/5-1/5-1.js
function createRandomIndex(){
    return Math.floor(Math.random()*10);
}
Page({
    data:{
        index:0,
        imgArray:[
            '/images/01.jpg',
            '/images/02.jpg',
            '/images/03.jpg',
            '/images/04.jpg',
            '/images/05.jpg',
            '/images/06.jpg',
            '/images/07.jpg',
            '/images/08.jpg',
            '/images/09.jpg',
            '/images/10.jpg'
        ],
    },
    faceChange:function(){
        let ran=createRandomIndex();
        this.setData({
            index:ran
        })
    },
    onShow:function(){
        var that=this;
        wx.onAccelerometerChange(function(res){
            if(res.x>0.5||res.y>0.5||res.z>0.5){
                wx.showToast({
                  title: '摇一摇成功',
                  icon:'success',
                  duration:2000
                })
            }
        })
    }
})