// pages/index/third/3-4/3-4.js
var indexmsg='我是本模块的变量'
function indexfunc(){
    return '我是本模块的函数'
}
Page({
    data:{
        msg1:indexmsg,
        msg2:indexfunc(),
    }
})