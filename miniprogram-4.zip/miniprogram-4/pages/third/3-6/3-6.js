// pages/indee/third/3-6/3-6.js
var level='0';
Page({
    data:{
        score:0
    },
    jLevel:function(x){
        this.setData({
            score:x.detail.value
        })
    }
})