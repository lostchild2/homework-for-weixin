// pages/third/3-9/3-9.js
Page({
    data:{
        stu1:{
            name:'张三',
            age:18,
            ginder:'男',
        },
        stu2:{
            name:'李四',
            age:19,
            ginder:'女',
        }
    }
})