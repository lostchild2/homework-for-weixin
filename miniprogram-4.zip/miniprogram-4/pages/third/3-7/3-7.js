// pages/index/third/3-7/3-7.js
Page({
    data:{
        arr:['张三','李四','王五','赵六'],
        object:{
            姓名:'张三',
            学号:'202020',
            性别:'男',
        }
    }
})