// pages/index/third/3-5/3-5.js
Page({
    data:{
        color:'blue',
        length:15
    }
})