// pages/fourth/4-10/4-10.js
Page({
    data:{
        getEmail:'',
        getPwd:'',
        getPwdConfirm:''
    },
    formSubmit:function(e){
        if(e.detail.value.email.length==0||e.detail.value.password.length==0){
            this.setData({
                showMsg01:'邮箱或密码不能为空',
                showMsg02:'',
            })
        }
        else if(e.detail.value.password!=e.detail.value.confirm){
            this.setData({
                showMsg01:'',
                showMsg02:'两次输入密码不一致',
                getPwd:'',
                getPwdConfirm:''
            })
        }
        else{
            wx.navigateTo({
                url:'../../fourth/detail/detail'
            })
        }
    },
    inputemail:function(e){
        var email=e.detail.value;
        var checkedNum=this.checkEmail(email);
    },
    checkEmail: function(email) { //自定义函数，检查输入的邮箱地址是否满足要求
        let str = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/ //正则表达式
        if (str.test(email)) { //检查正则表达式是否符合邮箱地址要求
          return true
        } else {
          wx.showToast({ //显示消息提示框
            title: '邮箱格式错误',
            icon: 'loading'
          })
          this.setData({
            getEmail: ''
          })
          return false
        }
      }
    
})