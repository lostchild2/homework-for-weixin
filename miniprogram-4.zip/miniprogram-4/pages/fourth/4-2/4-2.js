// pages/fourth/4-2/4-2.js
var a,b,c,s
Page({
    clear:function(){
        this.setData({
            a:'',
            b:'',
            c:'',
            area:''
        })
    },
    sum:function(e){
        a=parseFloat(e.detail.value.a);
        b=parseFloat(e.detail.value.b);
        c=parseFloat(e.detail.value.c);
        var area;
        if(a+b<c||a+c<b||b+c<a){
            wx.showToast({
              title: '不是三角形',
              duration:2000
            })
            
        }
        
        else{
            var p=(a+b+c)/2;
            s=Math.sqrt(p*(p-a)*(p-b)*(p-c))
        }
        this.setData({
            area:s
        })
    }

})