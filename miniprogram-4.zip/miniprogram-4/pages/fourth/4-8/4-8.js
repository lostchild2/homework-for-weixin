// pages/fourth/4-8/4-8.js
Page({
    data:{
        poster:'https://gimg3.baidu.com/yule/src=http%3A%2F%2Fgips3.baidu.com%2Fit%2Fu%3D2546366128%2C1823752566%26fm%3D3007%26app%3D3007%26f%3DJPEG%3Fw%3D500%26h%3D500&refer=http%3A%2F%2Fwww.baidu.com&app=2019&size=w931&n=0&g=0n&q=75&fmt=auto?sec=1673542800&t=491ed47d40382d4f9fa2190fdf121cf8',
        name:"有何不可",
        author:"许嵩",
        src:'http://dl.stream.qqmusic.qq.com/C4000036RQEx4fHEQF.m4a?guid=763936392&vkey=32ACB95960BA25147ADD9CB89A6F606A689C2267A6BF50DBF26B16D665F471453FA9FBCC6A87738A32EA658BA6B3AC2EA134EC1C4152E140&uin=&fromtag=120032',
    },
    onLoad:function(options){
        this.audioCtx=wx.createAudioContext('myAudio')
    },
    audioPlay:function(){
        this.audioCtx.play()
    },
    audioPause:function(){
        this.audioCtx.pause()
    },
    audio14:function(){
        this.audioCtx.seek(14)
    },
    audioStart:function(){
        this.audioCtx.seek(0)
    },
    
})

