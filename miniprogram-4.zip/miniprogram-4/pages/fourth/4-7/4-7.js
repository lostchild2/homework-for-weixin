// pages/fourth/4-7/4-7.js
Page({
    data:{
        imgArray:[{
            mode:'aspectFit',
            text:'aspectFit'
        },{
            mode:'scaleToFill',
            text:'scaleToFill'
        },{
            mode:'aspectFill',
            text:'aspectFill'
        },{
            mode:'top',
            text:'top'
        },{
            mode:'bottom',
            text:'bottom'
        },{
            mode:'center',
            text:'center'
        },{
            mode:'left',
            text:'left'
        },{
            mode:'right',
            text:'right'
        },{
            mode:'top left',
            text:'top left'
        },{
            mode:'bottom left',
            text:'bottom left'
        },{
            mode:'bottom right',
            text:'bottom right'
        }
    ]
    }
})