// pages/fourth/4-1/4-1.js
var y;
Page({
    sum:function(x){
        y=parseInt(x.detail.value.money);
        this.setData({
            my:(y/6.88).toFixed(4),
            yb:(y/8.78).toFixed(4),
            gb:(y/0.08).toFixed(4),
            eu:(y/7.82).toFixed(4),
            hy:(y/0.0061).toFixed(4),
            ry:(y/0.061).toFixed(4)
        })
    },
    reset:function(){
        this.setData({
            my:' ',
        yb:' ',
        gb:' ',
        eu:' ',
        hy:' ',
        ry:' '
        })
    }
    
})