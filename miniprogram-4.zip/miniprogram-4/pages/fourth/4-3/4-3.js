// pages/fourth/4-3/4-3.js
Page({
    data:{
        mySize:'15px'
    },
    checkboxChange:function(e){
        var text=[];
        var mybold=' ';
        var myitalic=' ';
        var myunderline=' ';
        text=e.detail.value;
        for(var i=0;i<text.length;i++){
            if(text[i]=='isBold'){
                mybold='bold';
            }
            if(text[i]=='isItalic'){
                myitalic='italic';
            }
            if(text[i]=='isUnderline'){
                myunderline='underline';
            }
        }
        this.setData({
            myBold:mybold,
            myItalic:myitalic,
            myUnderline:myunderline,
        })
    },
    radioChange:function(e){
        this.setData({
            mySize:e.detail.value,
        })
    }
})